<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'Admin User',
            'full_name' => 'System Admin',
            'email' => 'admin@example1.com',
            'mobile' => '9999999999',
            'password' => bcrypt('password'),
            'role' => 'admin',
            'is_verified' => true,
            'is_active' => true
        ]);
    }
}
